/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package globaldoctor;

import com.sun.jdi.connect.spi.Connection;

/**
 *
 * @author Ratul
 */
class DriverManager {

    static Connection getConnecton(String jdbcmysqllocalhostGlobalDoctor, String root, String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static Connection getConnection(String jdbcmysqllocalhostGlobalDoctoruseSSLfalse, String root, String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
